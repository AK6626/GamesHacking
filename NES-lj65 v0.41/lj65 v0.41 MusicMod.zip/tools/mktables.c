#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <limits.h>

// assert behaviors that the program relies on
extern char assert_CHAR_BIT_8[CHAR_BIT == 8 ? 1 : -1];

// NES clock speed is 39375000/22 Hz
// tone generators include a divide by 16 counter
// lowest note that we want to handle is 55 Hz
const double octaveBase = 39375000.0/(22 * 16 * 55);
enum {
  MAX_NOTE = 80
};


uint8_t periodTableLo[MAX_NOTE], periodTableHi[MAX_NOTE];

void dumpTable(const unsigned char *buf, size_t size, FILE *out) {
  unsigned int x = 0;
  for (size_t idx = 0; idx < size; ++idx) {
    if (x == 0) {
      fputs("  .byt ", stdout);
    } else {
      fputc(',', stdout);
    }
    printf("%3d", buf[idx]);
    if (++x >= 16) {
      x = 0;
      fputc('\n', stdout);
    }
  }
  if (x > 0) {
    x = 0;
    fputc('\n', stdout);
  }
}

int main(void) {
  size_t idx = 0;
  for (int octave = 0; idx < MAX_NOTE; ++octave) {
    double freq = octaveBase / (1 << octave);
    for (int semitone = 0;
         semitone < 12 && idx < MAX_NOTE;
         ++semitone, ++idx) {
      assert(idx == octave * 12 + semitone);  // loop invariant
      int iFreq = freq - 0.5;
      // printf("%2u:%4d\n", (unsigned int)idx, iFreq);
      periodTableLo[idx] = iFreq & 0xFF;
      periodTableHi[idx] = iFreq >> 8;
      freq = freq / 1.059463094;
    }
  }
  puts(".export periodTableLo, periodTableHi\n"
       ".segment \"RODATA\"\n"
       "periodTableLo:");
  dumpTable(periodTableLo, sizeof(periodTableLo), stdout);
  puts("periodTableHi:");
  dumpTable(periodTableHi, sizeof(periodTableHi), stdout);
  return EXIT_SUCCESS;
}
